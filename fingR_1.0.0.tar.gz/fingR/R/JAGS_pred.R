#' JAGS Predictions
#'
#' Generate and save a table with all the prediction of an JAGS model
#'
#' @param path
#' @param stats
#' @param save
#' @param note a character string to add a note at the end of the file name (not set - default).
#' @param fileEncoding character string, if non-empty declares the encoding to be used on a file (not a connection) so the character data can be re-encoded
#' as they are written, "latin1" (default).
#'
#' @author Thomas Chalaux Clergue
#'
#' @export
JAGS.pred <- function(path, stats, save = FALSE, note, fileEncoding = "latin1"){

  require(tidyr)

  # 1
  if(grepl(".txt", path)){ # summary txt file from MixSIAR output_JAGS function
    df.stats <- read.table(file = path, header = TRUE, skip = 7)

    if("Median" %in% stats){
      stats[which(stats == "Median")] <- "X50."
    }else if("50%" %in% stats){
      stats[which(stats == "50%")] <- "X50."
    }

    # look for mixture name and the source group
    for(i in 1:nrow(df.stats)){
      df.stats$sample[i] <- unlist(strsplit(row.names(df.stats[i,]), "[.]" ))[2]
      df.stats$source[i] <- unlist(strsplit(row.names(df.stats[i,]), "[.]" ))[3]
    }

  # 2
  }else if(grepl(".csv", path)){ # from JAGS.summary in fingR
    df.stats <- read.csv(file = path, header = TRUE)

    if("Median" %in% stats){
      stats[which(stats == "Median")] <- "Q50"
    }
  }

  df.stats <- df.stats[c("sample", "source", stats)]

  df.final <- tidyr::pivot_wider(df.stats, names_from = source, values_from = all_of(stats)) %>%
    as.data.frame()


  if("Q50" %in% stats){ #change median name as a easy to understand
    stats <- "Median"
  }

  if(length(stats) == 1){
    colnames(df.final)[2:4] <- paste(stats, colnames(df.final)[2:4], sep="_")
  }


  if(isTRUE(save)){
    file.name <- paste("ordered_statistics", paste(stats, collapse="-"), sep ="_")
    if(!missing(note)){
      file.name <- paste(file.name, note, sep="_")
    }
    path2 <- unlist(strsplit(path, split="[/]"))
    path2 <- paste(path2[1:(length(path2)-1)], collapse = "/")
    write.csv(df.final, paste(path2, paste(file.name, ".csv", sep=""), sep="/"), fileEncoding = fileEncoding, row.names = FALSE)
  }

  return(df.final)
}
