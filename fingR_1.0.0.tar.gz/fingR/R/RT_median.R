#' Median range test
#'
#' Assess the conservativity of a property based on the comparison of the sources and target medians.
#' The property is conservative if the target median value is between the highest and lowest sources medians.
#'
#' @param source a (non-empty) numeric vector of source values.
#' @param target a (non-empty) numeric vector of target values.
#'
#' @keywords fingerprinting, conservativity test
#'
#' @examples
#' \dontrun{test.median(target$Al_mg.kg, sources, "Class")}
#'
#' @author Thomas Chalaux-Clergue & Rémi Bizeul
#'
#' @export
RT.median <- function(target, sources, class, alternative = "single"){
  require(dplyr)

  property <- dplyr::setdiff(colnames(sources), class) #get the property label

  # sources mean
  source.bounds <- as.data.frame(sources) %>%
    dplyr::group_by(.data[[class]]) %>%
    dplyr::summarise(dplyr::across(.cols = all_of(property), .fns = list(median)))

  source.bounds[2] <- round(source.bounds[2], lvl.signif(sources[[property]]))

  #get min of min and max of max add some measurement error if set (MM.error)
  bound.s <- c(min(source.bounds[2]), max(source.bounds[2]))

  if(alternative == "single"){ # for each target sample
    resu <- list()
    resu[["sample.RT"]] <- bound.s[1] <= target & target <= bound.s[2]
    resu[["RT.pass"]] <- !(FALSE %in% resu[["sample.RT"]])

  }else if(alternative == "population"){ # consider target as a population
    resu <- bound.s[1] <= round(median(target), lvl+3) & round(median(target), lvl+3) <= bound.s[2]
  }
  return(resu)
}
